test.AddQuestion( new Question ("question_1",
 "Cao độ là gì ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Mức độ trầm bổng của âm thanh. (T)" ,"Mức độ ngắn dài của âm thanh."),
 "Mức độ trầm bổng của âm thanh. (T)","obj_1"));
test.AddQuestion( new Question ("question_2",
 "Mức độ ngắn dài của âm thanh là gì ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Trường độ (T)" ,"Cao độ"),
 "Trường độ (T)","obj_2"));
test.AddQuestion( new Question ("question_3",
 "Trường độ là gì ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Mức độ ngắn dài của âm thanh. (T)" ,"Độ mạnh các nốt nhạc."),
 "Mức độ ngắn dài của âm thanh. (T)","obj_3"));
test.AddQuestion( new Question ("question_4",
 "Ví dụ về Cường độ âm thanh là ? ", 
 QUESTION_TYPE_CHOICE,
 new Array("Tiếng thác chảy. (T)" ,"Tiếng đồng hồ."),
 "Tiếng thác chảy. (T)","obj_4"));
test.AddQuestion( new Question ("question_5",
 "Tiếng thác chảy mô tả :", 
 QUESTION_TYPE_CHOICE,
 new Array("Cao độ" ,"Cường độ (T)"),
 "Cường độ (T)","obj_5"));
test.AddQuestion( new Question ("question_6",
 "Định nghĩa đúng về âm sắc là ? ", 
 QUESTION_TYPE_CHOICE,
 new Array("Những âm thanh khác nhau về cường độ." ,"Những âm thanh giống nhau về Cao độ, Trường độ, Cường độ nhưng chúng khác nhau về âm sắc. (T)"),
 "Những âm thanh giống nhau về Cao độ, Trường độ, Cường độ nhưng chúng khác nhau về âm sắc. (T)","obj_6"));
test.AddQuestion( new Question ("question_7",
 "Khuông nhạc dùng để biểu diễn ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Các thông tin về bản nhạc. (T)" ,"Độ mạnh yếu các nốt nhạc."),
 "Các thông tin về bản nhạc. (T)","obj_7"));
test.AddQuestion( new Question ("question_8",
 "Số dòng kẻ trong một khuông nhạc là :", 
 QUESTION_TYPE_CHOICE,
 new Array("4" ,"5 (T)"),
 "5 (T)","obj_8"));
test.AddQuestion( new Question ("question_9",
 "Giữa các dòng kẻ gọi là ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Dấu hóa." ,"Khe nhạc. (T)"),
 "Khe nhạc. (T)","obj_9"));
test.AddQuestion( new Question ("question_10",
 "Vị trí các khe nhạc nằm ở ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Giữa các dòng kẻ nhạc. (T)" ,"Trong một bản nhạc."),
 "Giữa các dòng kẻ nhạc. (T)","obj_10"));
