test.AddQuestion( new Question ("question_1",
 "Võ công mạnh nhất của Tiêu Phong là gì ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Giáng long thập bát chưởng (C)" ,"Đả cổng bổng pháp" ,"Lục Mạch Thần Kiếm" ,"Đấu chuyển tinh di"),
 "Giáng long thập bát chưởng (C)","obj_1"));
test.AddQuestion( new Question ("question_2",
 "Tiêu Phong là bang chủ Cái Bang đời thứ ? ", 
 QUESTION_TYPE_CHOICE,
 new Array("6 (C)" ,"7" ,"8" ,"9"),
 "6 (C)","obj_2"));
test.AddQuestion( new Question ("question_3",
 "Hư Trúc là hòa thượng của chùa ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Chùa Thiên Long" ,"Chùa Thiếu Lâm (C)" ,"Chùa Đại Tuyết" ,"Chùa Đại Luân"),
 "Chùa Thiếu Lâm (C)","obj_3"));
test.AddQuestion( new Question ("question_4",
 "Hư Trúc được nhận nội công từ những vị cao thủ phái Tiêu Dao, những vị đó là ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Vô Nhai Tử, Đoàn Diên Khánh, Lý Thu Thủy" ,"Vô Nhai Tử, Thiên Sơn Đồng Lão, Nam Hải Ngạc Thần" ,"Vô Nhai Tử, Thiên Sơn Đồng Lão, Lý Thu Thủy (C)" ,"Vô Nhai Tử, Đoàn Diên Khánh, Nam Hải Ngạc Thần"),
 "Vô Nhai Tử, Thiên Sơn Đồng Lão, Lý Thu Thủy (C)","obj_4"));
test.AddQuestion( new Question ("question_5",
 "Đoàn Dự là con ruột của ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Đoàn Diên Khánh - Đao Bạch Phượng (C)" ,"Đoàn Diên Khánh - Tần Hồng Miên" ,"Đoàn Chính Thuần - Đao Bạch Phượng" ,"Đoàn Chính Thuần - Tần Hồng Miên"),
 "Đoàn Diên Khánh - Đao Bạch Phượng (C)","obj_5"));
