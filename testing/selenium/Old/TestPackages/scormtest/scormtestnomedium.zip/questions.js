test.AddQuestion( new Question ("question_1",
 "Tiêu Phong là người gì ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Người Khiết Đan (C)" ,"Người Tây Hạ" ,"Người Đại Lý" ,"Người Đại Liêu"),
 "Người Khiết Đan (C)","obj_1"));
test.AddQuestion( new Question ("question_2",
 "Tứ Đại Ác Nhân bao gồm:", 
 QUESTION_TYPE_CHOICE,
 new Array("Đoàn Diên Khánh, Vân Trung Hạc, Mộ Dung Phục, Vương Ngữ Yên." ,"Nam Hải Ngạc Thần, Tô Tinh Hà, Vân Trung Hạc, Diệp Nhị Nương." ,"Đoàn Diên Khánh, Diệp Nhị Nương, Nam Hải Ngạc Thần, Mộ Dung Phục." ,"Đoàn Diên Khánh, Vân Trung Hạc, Nam Hải Ngạc Thần, Diệp Nhị Nương (C)"),
 "Đoàn Diên Khánh, Vân Trung Hạc, Nam Hải Ngạc Thần, Diệp Nhị Nương (C)","obj_2"));
test.AddQuestion( new Question ("question_3",
 "Hư Trúc là hòa thượng của chùa ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Chùa Thiên Long" ,"Chùa Thiếu Lâm (C)" ,"Chùa Đại Tuyết" ,"Chùa Đại Luân"),
 "Chùa Thiếu Lâm (C)","obj_3"));
test.AddQuestion( new Question ("question_4",
 "Những tuyệt kỹ của Hư Trúc là ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Bắc Minh Thần Công, Bát Hoang Lục Hợp Duy Ngã Độc Tôn Công, Lục Mạch Thần Kiếm." ,"Bắc Minh Thần Công, Lăng Ba Vi Bộ, Tiểu Vô Tướng Công" ,"Bắc Minh Thần Công, Thiên Sơn Lục Dương Chưởng, Sinh Thổ Phù. (C)" ,"Tất cả đều sai"),
 "Bắc Minh Thần Công, Thiên Sơn Lục Dương Chưởng, Sinh Thổ Phù. (C)","obj_4"));
test.AddQuestion( new Question ("question_5",
 "Đoàn Dự là con ruột của ?", 
 QUESTION_TYPE_CHOICE,
 new Array("Đoàn Diên Khánh - Đao Bạch Phượng (C)" ,"Đoàn Diên Khánh - Tần Hồng Miên" ,"Đoàn Chính Thuần - Đao Bạch Phượng" ,"Đoàn Chính Thuần - Tần Hồng Miên"),
 "Đoàn Diên Khánh - Đao Bạch Phượng (C)","obj_5"));
